﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.SqlServer.Server;
using MilestoneCIII.Models;
using MilestoneCIII.Services;
using System.Drawing;

namespace MilestoneCIII.Controllers
{
    public class GameController : Controller
    {
        static List<ButtonModel> buttons = new List<ButtonModel>();
        static BoardModel gameBoard = new BoardModel();

        // display the initial game board.
        public IActionResult Index()
        {
            buttons = new List<ButtonModel>();
            int Id = 0;
           for (int i = 0; i < 9; i++)
            {
                for(int j = 0; j < 9; j++)
                {
                    buttons.Add(new ButtonModel(Id, j, i, 0));
                    Id++;
                }
            }
            gameBoard.SetupLiveNeighbors();
            gameBoard.CalculateLiveNeighbors();
            return View("Index", buttons);
        }

        // display only the grid.  No menu.
        [HttpPost]
        public IActionResult HandleLiveButtonClick(string buttonNumber)
        {
            int bN = int.Parse(buttonNumber);
            int X = buttons[bN].X;
            int Y = buttons[bN].Y;
            if (gameBoard.gameBoard[X, Y].IsFlagged == true)
            {
                buttons[bN].ButtonState = 0;
                gameBoard.gameBoard[X, Y].IsFlagged = false;
                return PartialView("LiveGame", buttons);
            }
            if (gameBoard.gameBoard[X, Y].Bomb == true)
            {
                buttons[bN].ButtonState = 6;
                return PartialView("GameLost");
            }
            else
            {
                gameBoard.FloodFill(gameBoard, X, Y);
            }
            int location = 0;
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (gameBoard.gameBoard[j, i].CurrentlyOccupied == true)
                    {
                        if (gameBoard.gameBoard[j, i].Neighbors > 0 && gameBoard.gameBoard[j, i].Bomb == false)
                        {
                            buttons.ElementAt(location).ButtonState = int.Parse(gameBoard.gameBoard[j, i].Neighbors.ToString());
                        }
                        else
                        {
                            buttons.ElementAt(location).ButtonState = 7;
                        }
                    }
                    location++;
                }

            }
            int totalRevealed = 0;
            for (int r = 0; r < 9; r++)
            {
                for (int c = 0; c < 9; c++)
                {
                    CellModel cell = gameBoard.gameBoard[r, c];
                    if (cell.CurrentlyOccupied == true)
                    {
                        totalRevealed++;
                    }
                }
            }
            if (totalRevealed == (9 * 9) - gameBoard.ActualBombs)
            {
                return PartialView("GameWon");
            }
            return PartialView("LiveGame", buttons);
        }
        //public IActionResult HandleButtonClick(string buttonNumber)
        //{
        //    int bN = int.Parse(buttonNumber);
        //    int X = buttons[bN].X;
        //    int Y = buttons[bN].Y;
        //    if (gameBoard.gameBoard[X, Y].Bomb == true){
        //        buttons[bN].ButtonState = 6;
        //        return View("GameLost");
        //    }
        //    else
        //    {
        //        gameBoard.FloodFill(gameBoard, X, Y);
        //    }
        //    int location = 0;
        //    for(int i = 0; i < 9; i++)
        //    {
        //        for (int j = 0; j < 9; j++)
        //        {
        //            if (gameBoard.gameBoard[j, i].CurrentlyOccupied == true)
        //            {
        //                if (gameBoard.gameBoard[j, i].Neighbors > 0)
        //                {
        //                    buttons.ElementAt(location).ButtonState = int.Parse(gameBoard.gameBoard[j, i].Neighbors.ToString());
        //                }
        //                else
        //                {
        //                    buttons.ElementAt(location).ButtonState = 7;
        //                }
        //            }
        //            location++;
        //        }

        //    }
        //    int totalRevealed = 0;
        //    for (int r = 0; r < 9; r++)
        //    {
        //        for (int c = 0; c < 9; c++)
        //        {
        //            CellModel cell = gameBoard.gameBoard[r, c];
        //            if (cell.CurrentlyOccupied == true)
        //            {
        //                totalRevealed++;
        //            }
        //        }
        //    }
        //    if (totalRevealed == (9 * 9) - gameBoard.ActualBombs)
        //    {
        //        return View("GameWon");   
        //    }
        //    return View("Index", buttons);
        //}
        [HttpPost]
        public IActionResult FlagButton(string buttonNumber)
        {
            int bN = int.Parse(buttonNumber);
            int X = buttons[bN].X;
            int Y = buttons[bN].Y;
            gameBoard.gameBoard[X, Y].IsFlagged = true;
            buttons[bN].ButtonState = 8;
            return PartialView("LiveGame", buttons);
        }

        public IActionResult SaveGamePage()
        {
            return View("SaveGame");
        }
        public IActionResult SaveGame(GameStateModel game)
        {
            GameStateService gameService = new GameStateService();
  
            if (gameService.IsValid(game))
            {
                return View("SaveSuccess");
            }
            else
            {
                return View("SaveGame");
            }
            
        }
    }
}
