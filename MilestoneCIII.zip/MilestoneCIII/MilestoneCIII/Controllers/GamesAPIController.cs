﻿using Microsoft.AspNetCore.Mvc;
using MilestoneCIII.Models;
using MilestoneCIII.Services;

namespace MilestoneCIII.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GamesAPIController : ControllerBase
    {
        GameStateDAO repository = new GameStateDAO();

        public GamesAPIController() 
        { 
            repository = new GameStateDAO();
        }
        [HttpGet]
        public IEnumerable<GameStateModel> Index()
        {
            List<GameStateModel> games = repository.GetAllGames();
            return games;
        }
        [HttpGet("game/{Id}")]
        public ActionResult <GameStateModel> GetGameById(int Id)
        {
            GameStateModel game = repository.GetGameById(Id);
            return game;
        }
        [HttpDelete("game/{Id}")]
        public string DeleteGame(int Id)
        {
            if (repository.Delete(Id))
            {
                return "Delete Success";
            }
            else
            {
                return "Delete Failure";
            }
        }
    }
}
