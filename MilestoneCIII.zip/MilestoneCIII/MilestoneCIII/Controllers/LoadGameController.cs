﻿using Microsoft.AspNetCore.Mvc;
using MilestoneCIII.Services;

namespace MilestoneCIII.Controllers
{
    public class LoadGameController : Controller
    {
        GameStateDAO gameStateDAO = new GameStateDAO();
        public IActionResult Index()
        {
            return View(gameStateDAO.GetAllGames());
        }
        public IActionResult Delete(int id)
        {
            if (gameStateDAO.Delete(id))
            {
                return View("Index", gameStateDAO.GetAllGames());
            }
            else
            {
                return View("Index", gameStateDAO.GetAllGames());
            }
        }
    }
}
