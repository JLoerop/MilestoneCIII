﻿using Microsoft.AspNetCore.Mvc;
using MilestoneCIII.Models;
using MilestoneCIII.Services;

namespace MilestoneCIII.Controllers
{
    public class RegisterController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Success(UserModel user)
        {
            RegisterService registerService = new RegisterService();
            if (registerService.IsValid(user))
            {
                return View("RegisterSuccess", user);
            }
            else
            {
                return View("Index", user);
            }
            
        }
    }
}
