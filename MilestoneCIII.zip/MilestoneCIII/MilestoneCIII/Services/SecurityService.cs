﻿using MilestoneCIII.Models;

namespace MilestoneCIII.Services
{
    public class SecurityService
    {
        SecurityDAO securityDAO = new SecurityDAO();

        public bool IsValid(LoginModel user)
        {
            return securityDAO.FindUserByNameAndPassword(user);
        }
    }
}
