﻿using MilestoneCIII.Models;
using System.Data.SqlClient;

namespace MilestoneCIII.Services
{
    public class GameStateDAO
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public bool InsertGame(GameStateModel game)
        {
            string sqlStatement = "INSERT INTO dbo.Game (BOARD, NAME) VALUES (@board, @name)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.Add("@board", System.Data.SqlDbType.NVarChar, 100000000).Value = game.Game;
                command.Parameters.Add("@name", System.Data.SqlDbType.NVarChar, 50).Value = game.Name;

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();
                return rowsAffected > 0;
            }
        }
        public List<GameStateModel> GetAllGames() 
        {
            List<GameStateModel> foundGames = new List<GameStateModel>();
            string sqlStatment = "SELECT * FROM dbo.Game";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatment, connection);
                
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        foundGames.Add(new GameStateModel((int)reader[0], (string)reader[1], (string)reader[2]));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
            }
            return foundGames;
        }
        public bool Delete(int id)
        {
            bool success = false;

            string sqlStatement = "DELETE FROM dbo.Game WHERE Id = @id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@id", id);
                try
                {
                    connection.Open();
                    int rows = command.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        success = true;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
            }
            return success;
        }
        public GameStateModel GetGameById(int id)
        {
           GameStateModel model = new GameStateModel();

            string sqlStatement = "SELECT * FROM dbo.Game WHERE Id = @id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@id", id);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        model = new GameStateModel((int)reader[0], (string)reader[1], (string)reader[2]);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                };
            }
            return model;
        }
    }
}
