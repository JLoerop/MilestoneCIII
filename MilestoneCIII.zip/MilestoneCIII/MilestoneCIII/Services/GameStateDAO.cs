﻿using MilestoneCIII.Models;
using System.Data.SqlClient;

namespace MilestoneCIII.Services
{
    public class GameStateDAO
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public bool InsertGame(GameStateModel game)
        {
            string sqlStatement = "INSERT INTO dbo.Game (BOARD, NAME) VALUES (@board, @name)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.Add("@board", System.Data.SqlDbType.NVarChar, 100000000).Value = game.Game;
                command.Parameters.Add("@name", System.Data.SqlDbType.NVarChar, 50).Value = game.Name;


                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();
                return rowsAffected > 0;
            }
        }
    }
}
