﻿using MilestoneCIII.Models;

namespace MilestoneCIII.Services
{
    public class GameStateService
    {
        GameStateDAO gameDAO = new GameStateDAO();

        public List<GameStateModel> getGames()
        {
            return gameDAO.GetAllGames();
        }
        public bool IsValid(GameStateModel game)
        {
            return gameDAO.InsertGame(game);
        }
        public bool Delete(int id)
        {
            return gameDAO.Delete(id);
        }
        public GameStateModel GetGameById(int id)
        {
            return gameDAO.GetGameById(id);
        }
        
    }
}
