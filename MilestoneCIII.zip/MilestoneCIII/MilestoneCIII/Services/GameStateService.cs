﻿using MilestoneCIII.Models;

namespace MilestoneCIII.Services
{
    public class GameStateService
    {
        GameStateDAO gameDAO = new GameStateDAO();

        public bool IsValid(GameStateModel game)
        {
            return gameDAO.InsertGame(game);
        }
    }
}
