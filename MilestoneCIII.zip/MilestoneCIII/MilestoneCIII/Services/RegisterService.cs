﻿using MilestoneCIII.Models;

namespace MilestoneCIII.Services
{
    public class RegisterService
    {
        RegisterDAO registerDAO = new RegisterDAO();

        public bool IsValid(UserModel user)
        {
            return registerDAO.InsertUser(user);
        }
    }
}
