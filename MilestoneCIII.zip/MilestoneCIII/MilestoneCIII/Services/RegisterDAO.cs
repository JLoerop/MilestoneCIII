﻿using MilestoneCIII.Models;
using System.Data.SqlClient;
using System.Linq;

namespace MilestoneCIII.Services
{
    public class RegisterDAO
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Users;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public bool InsertUser(UserModel user)
        {
            string sqlStatement = "INSERT INTO dbo.users (USERNAME, PASSWORD, FIRSTNAME, LASTNAME, SEX, AGE, EMAIL, STATE) VALUES (@username, @password, @firstname, @lastname, @sex, @age, @email, @state)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.Add("@username", System.Data.SqlDbType.NVarChar, 50).Value = user.UserName;
                command.Parameters.Add("@password", System.Data.SqlDbType.NVarChar, 50).Value = user.Password;
                command.Parameters.Add("@firstname", System.Data.SqlDbType.NVarChar, 50).Value = user.FirstName;
                command.Parameters.Add("@lastname", System.Data.SqlDbType.NVarChar, 50).Value = user.LastName;
                command.Parameters.Add("@sex", System.Data.SqlDbType.NVarChar, 50).Value = user.Sex;
                command.Parameters.Add("@age", System.Data.SqlDbType.Int, 50).Value = user.Age;
                command.Parameters.Add("@email", System.Data.SqlDbType.NVarChar, 100).Value = user.Email;
                command.Parameters.Add("@state", System.Data.SqlDbType.NVarChar, 50).Value = user.State;

                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();
                return rowsAffected > 0;
            }
        }
    }
    
}
