﻿namespace MilestoneCIII.Models
{
    public class GameStateModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Game {  get; set; }
    }
}
