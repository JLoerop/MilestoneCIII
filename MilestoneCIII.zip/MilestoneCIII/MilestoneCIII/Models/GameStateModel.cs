﻿namespace MilestoneCIII.Models
{
    public class GameStateModel
    {
        

        public int Id { get; set; }
        public string Name { get; set; }
        public string Game {  get; set; }


        public GameStateModel(int id, string game, string name)
        {
            Id = id;
            Game = game;
            Name = name;

        }
        public GameStateModel() { }
    }
}
