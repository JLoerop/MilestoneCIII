﻿namespace MilestoneCIII.Models
{
    public class ButtonModel
    {
        public int Id { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int ButtonState { get; set; }
        public string Text { get; set; }
        public ButtonModel() 
        {
            
        }
        public ButtonModel(int id, int x, int y, int buttonState)
        {
            Id = id;
            X = x;
            Y = y;
            ButtonState = buttonState;
        }
    }
}
