﻿using Microsoft.SqlServer.Server;

namespace MilestoneCIII.Models
{
    public class BoardModel
    {
        public int Size { get; set; }
        public double TotalBombs { get; set; }
        public bool GameLost { get; set; }
        public double ActualBombs { get; set; }

        public BoardModel()
        {
            Size = 9;
            TotalBombs = 5;

            gameBoard = new CellModel[Size, Size];

            for (int row = 0; row < Size; row++)
            {
                for (int column = 0; column < Size; column++)
                {
                    gameBoard[row, column] = new CellModel(row, column, false, 0, false, false);
                }
            }
        }
        public CellModel[,] gameBoard;
       /** public BoardModel(int size, int totalBombs)
        {
             Size = size;
            TotalBombs = totalBombs;

            gameBoard = new CellModel[size, size];

            for (int i = 0; i < Size; i++)
            {
                for (int x = 0; x < Size; x++)
                {
                    gameBoard[i, x] = new CellModel(i, x, false, 0, false, false);
                }
            }
        }
       **/
        /// <summary>
        /// Method that will go through each cell and give a random chance at being a bomb.
        /// </summary>
        public void SetupLiveNeighbors()
        {
            Random rnd = new Random();
            for (int row = 0; row < Size; row++)
            {
                for (int column = 0; column < Size; column++)
                {
                    int rand = rnd.Next(1, 100);
                    if (rand <= TotalBombs)
                    {
                        gameBoard[row, column].Bomb = true;
                        ActualBombs++;
                    }
                }
            }
        }
        // out of bounds method
        public bool InBounds(int row, int column)
        {
            if (row >= 0 && row <= Size && column >= 0 && column <= Size)
            {
                return true;
            }
            else return false;
        }
        // flood fill method
        public void FloodFill(BoardModel board, int row, int column)
        {
            try
            {
                if (board.InBounds(row, column) && board.gameBoard[row, column].Neighbors == 0)
                {
                    if (board.gameBoard[row, column].CurrentlyOccupied != true)
                    {
                        board.gameBoard[row, column].CurrentlyOccupied = true;
                        FloodFill(board, row + 1, column);
                        FloodFill(board, row - 1, column);
                        FloodFill(board, row, column + 1);
                        FloodFill(board, row, column - 1);
                    }
                }
                else if (board.InBounds(row, column) && board.gameBoard[row, column].Neighbors >= 1)
                {
                    board.gameBoard[row, column].CurrentlyOccupied = true;
                }
            }
            catch
            {

            }

        }
        // method that sets the selected cell to be occupied.
        public void SetCurrentCell(CellModel currentCell)
        {
            gameBoard[currentCell.Row, currentCell.Column].CurrentlyOccupied = true;
        }
        /// <summary>
        /// method that calculates the amount of bombs around the cell
        /// </summary>
        public void CalculateLiveNeighbors()
        {
            for (int row = 0; row < Size; row++)
            {
                for (int column = 0; column < Size; column++)
                {
                    // is row-1 on the board?
                    if (row - 1 >= 0)
                    {

                        // check north cell
                        if (gameBoard[row - 1, column].Bomb == true)
                        {
                            gameBoard[row, column].Neighbors++;
                        }

                    }

                    if (row - 1 >= 0 && column - 1 >= 0)
                    {
                        if (gameBoard[row - 1, column - 1].Bomb == true)
                        {
                            gameBoard[row, column].Neighbors++;
                        }
                    }

                    if (column - 1 >= 0)
                    {
                        if (gameBoard[row, column - 1].Bomb == true)
                        {
                            gameBoard[row, column].Neighbors++;
                        }
                    }
                    if (row + 1 < Size && column - 1 >= 0)
                    {
                        if (gameBoard[row + 1, column - 1].Bomb == true)
                        {
                            gameBoard[row, column].Neighbors++;
                        }
                    }
                    if (row - 1 >= 0 && column + 1 < Size)
                    {
                        if (gameBoard[row - 1, column + 1].Bomb == true)
                        {
                            gameBoard[row, column].Neighbors++;
                        }
                    }
                    if (row + 1 < Size)
                    {
                        if (gameBoard[row + 1, column].Bomb == true)
                        {
                            gameBoard[row, column].Neighbors++;
                        }
                    }
                    if (row + 1 < Size && column + 1 < Size)
                    {
                        if (gameBoard[row + 1, column + 1].Bomb == true)
                        {
                            gameBoard[row, column].Neighbors++;
                        }
                    }
                    if (column + 1 < Size)
                    {
                        if (gameBoard[row, column + 1].Bomb == true)
                        {
                            gameBoard[row, column].Neighbors++;
                        }
                    }


                }

            }


        }
    }
}
