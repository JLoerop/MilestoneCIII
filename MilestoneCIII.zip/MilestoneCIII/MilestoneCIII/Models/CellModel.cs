﻿namespace MilestoneCIII.Models
{
    public class CellModel
    {
        public int Row { get; set; }
        public int Column { get; set; }
        public bool Bomb { get; set; }
        public int Neighbors { get; set; }
        public bool CurrentlyOccupied { get; set; }
        public bool IsFlagged { get; set; }

        
        public CellModel()
        {
           
        }
        

        public CellModel(int row, int column, bool bomb, int neighbors, bool currentlyoccupied, bool isflagged)
        {
            Row = row;
            Column = column;
            Bomb = bomb;
            Neighbors = neighbors;
            CurrentlyOccupied = currentlyoccupied;
            IsFlagged = isflagged;
        }
    }
}
